let names  : string[] = ["friend name 1","friend name 2","friend name 3"];
console.log(names[0]);
console.log(names[1]);
console.log(names[2]);
