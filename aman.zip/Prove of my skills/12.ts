let names  : string[] = ["friend name 1","friend name 2","friend name 3"];
for(var Name of names){
    console.log("Greetings! "+ Name);
}