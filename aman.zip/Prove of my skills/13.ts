let vehicles : string[] = ["Corolla Car","Helicopter","Hillux","Fortuner"];
for(var Name of vehicles){
    console.log("I would like to own a "+ Name);
}