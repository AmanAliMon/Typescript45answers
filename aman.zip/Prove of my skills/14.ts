let guests : string[] = ["Dear friend","My laptop","Someone","Good Czn"];
for(var Name of guests){
    console.log( Name+ "! I would like to invite you to join us for dinner at Dd-MM-YY ");
}