let guests : string[] = ["Dear friend","My laptop","Someone","Good Czn","Prime Minister"];

console.log("\tJust got a pretty large table!");

guests =["Boss", ...guests]
let l :number = guests.length
let new_guests : string[] = []
for (let i = 0; i < l/2; i++) {
    new_guests.push(guests[i]);    
}
new_guests.push("Middle Bro")

for (let i = l/2; i < l; i++) {
    console.log(l);
    console.log(i);
    
    new_guests.push(guests[i]);    
}
new_guests.push("Last bro")
for(var Name of new_guests){
    console.log( Name+ "! I would like to invite you to join us for dinner at Dd-MM-YY ");
}
