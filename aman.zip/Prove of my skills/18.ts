let places : string[] = ["Rio de jaaerio","vegas","Los Angelos","Vancouver","Modern tower"]
console.log(places);
console.log([...places].sort());
console.log(places);
console.log(places.reverse());
console.log(places.sort());




