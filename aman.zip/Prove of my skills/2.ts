const NAME : string = "Aman";
console.log(`Man! ${NAME} is really a great programmer.`);
