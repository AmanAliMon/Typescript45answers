let some_langs_i_know : string[] = ["C++","JavaScript","Python","HTML","PHP","Java","TypeScript"];
for(const lang of some_langs_i_know){
    console.log(lang);
    
}