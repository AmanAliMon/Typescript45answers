let arr : number[] = [1,2,3,4,5]
    console.log(arr[6]);
    console.log(arr[arr.length-1]);   