let Name : string = "Aman";

console.log("Is Name == `Aman`,I predict True");
console.log(Name=="Aman");
console.log("Is 7+8 = 15, i predict True");
console.log(7+8==15);
console.log("Is Name not Ali, I predict True");
console.log(Name!="Ali");
console.log("28 is a even number, I predict true`");
console.log(28%2==0);
console.log("My name is a string? I predict true");
console.log(typeof(Name) == "string");


console.log("Is Name == `Ali`,I predict False");
console.log(Name=="Ali");
console.log("Is 7+7 = 15, i predict False");
console.log(7+7==15);
console.log("Is Name Ali, I predict False");
console.log(Name=="Ali");
console.log("27 is a even number, I predict False`");
console.log(27%2==0);
console.log("My name is a number I predict False");
console.log(typeof(Name) == "number");