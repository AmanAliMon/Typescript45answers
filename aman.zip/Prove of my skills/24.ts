let str : string = "Paris"

console.log("String may be paris");
console.log(str=="Paris");
console.log("String may not be karachi");
console.log(str!="Karachi");


console.log("paris is lowercase of str");
console.log("paris"==str.toLowerCase());


console.log("I know 2 is greater than 1");
console.log(2>1);
console.log("2 is less than 3; 4<3 will return false");
console.log(4<3);

console.log("Paris has more than or equals to 4 characters");
console.log(str.length>=4);
console.log("Paris has less than or equals to 5 characters");
console.log(str.length<=5);

console.log("str must paris or france");

console.log(str=="Paris"||str=="France");

console.log("str must paris and with capital P");
console.log(str=="Paris"&&str[0] == "P");


let US_states : string[]= ["New York","Indiana","Vegas","Los Angelos","Washington","Salt lake city"]
console.log("Is new york is in USA");
console.log(US_states.includes("Vegas"));

console.log("karachi is not in USA");
console.log(!(US_states.includes("Karachi")));


