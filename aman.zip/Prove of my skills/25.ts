// If will fail here v1

var alien_color : string = "green";
if(alien_color == "green"){
    console.log("5 points rewarded");
    
}


// If will pass here v2

var alien_color : string = "red";
if(alien_color == "green"){
    console.log("5 points rewarded");
    
}