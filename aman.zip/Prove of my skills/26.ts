// If will pass to if here v1

var alien_color : string = "green";
if(alien_color == "green"){
    console.log("5 points rewarded");
}else{
    console.log("10 points rewarded");
    
}


// If will go to else here v2

var alien_color : string = "red";
if(alien_color == "green"){
    console.log("5 points rewarded");
}else{
    console.log("10 points rewarded");
    
}
