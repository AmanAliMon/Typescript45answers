// If will pass to if here v1

var alien_color : string = "green";
if(alien_color == "green"){
    console.log("5 points rewarded");
}else if (alien_color == "yellow"){
    console.log("10 points rewarded");
    
}else if (alien_color == "red"){
    console.log("15 points rewarded");
}


//v2

var alien_color : string = "red";
if(alien_color == "green"){
    console.log("5 points rewarded");
}else if (alien_color == "yellow"){
    console.log("10 points rewarded");
    
}else if (alien_color == "red"){
    console.log("15 points rewarded");
}


//v3
var alien_color : string = "yellow";
if(alien_color == "green"){
    console.log("5 points rewarded");
}else if (alien_color == "yellow"){
    console.log("10 points rewarded");
    
}else if (alien_color == "red"){
    console.log("15 points rewarded");
}
