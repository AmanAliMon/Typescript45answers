let fruits : string[] = ["Mango","Apple","Banana"]
for(var fruit of fruits){
    if(fruit=="Mango"){
        console.log("You really like Mango");
        
    }    if(fruit=="Pineapple"){
        console.log("You really like Pineapple");
        
    }    if(fruit=="Watermelon"){
        console.log("You really like Watermelon");
        
    }    if(fruit=="Apple"){
        console.log("You really like Apple");
        
    }    if(fruit=="Banana"){
        console.log("You really like Banana");
        
    }
}