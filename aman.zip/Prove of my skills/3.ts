const NAME : string = "Aman";
console.log(NAME.toUpperCase());
console.log(NAME.toLowerCase());
console.log(NAME[0].toUpperCase() + NAME.substring(1));
