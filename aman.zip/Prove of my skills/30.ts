let users : string[] = ["Aman","Ali","Aman Ali","Admin","Another Aman"]
for(var user of users){
    if(user=="Admin"){
        console.log("Hello, Admin! Would you like to see a report");
        
    }else{
        console.log("Welcome back "+user+"! Thanks for logging in");
        
    }
}