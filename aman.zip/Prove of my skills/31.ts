var users = [];

if(users.length == 0){
    console.log("We need to find some users");
    
}

for (var _i = 0, users_1 = users; _i < users_1.length; _i++) {
    var user = users_1[_i];
    if (user == "Admin") {
        console.log("Hello, Admin! Would you like to see a report");
    }
    else {
        console.log("Welcome back " + user + "! Thanks for logging in");
    }
}
