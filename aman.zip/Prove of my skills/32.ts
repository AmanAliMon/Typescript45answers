let current_users : string[] = ["aman","1Aman","TheAMAN","AmAN ali","aMAn civil wars"]
let new_users : string[] = ["aman returns","aman far from college","aman the new user","aman of all stacks","aman apocalypse","AMAN"]

for(var new_user of new_users){
    let available = true
for (const current_user of current_users) {
    if(new_user.toLowerCase() == current_user.toLowerCase()){
        available = false
        console.log("user already exists: " + new_user);
    }
}
if(available){
    console.log("Name is available: "+ new_user);
}

}