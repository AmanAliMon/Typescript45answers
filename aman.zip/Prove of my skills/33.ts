let rank : number[] = [1,2,3,4,5,6,7,8,9]

for (const r of rank) {
    switch (r) {
        case 1:
            console.log("1st");
            break;
                    case 2:
            console.log("2nd");
            break;
                    case 3:
            console.log("3rd");
            break;
    
        default:
            console.log(`${r}th`);
            
            break;
    }
}