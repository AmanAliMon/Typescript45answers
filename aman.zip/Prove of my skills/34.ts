let pizzas : string[] = ["Pepproni Pizza","Cheese Pizza","Pineapple Pizza"];
for (let index = 0; index < pizzas.length; index++) {
    console.log(`I really like ${pizzas[index]}`);
}
console.log("I love pizza");
