let pets : string[] = ["Dog","Cat","Goat"]
for (let i = 0; i < pets.length; i++) {
console.log(`${pets[i]} would be a great pet`);
}

console.log("These all are cute pets especially the goat");
console.log("Any of above could be a great pet");

