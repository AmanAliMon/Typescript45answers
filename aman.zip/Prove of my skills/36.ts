function make_shirt(size : string,message : string) : void {
    console.log(`Make a shirt of size ${size} with content ${message}! Noted`);
    
}
make_shirt("L","<CODE BLOODED/>")