function make_shirt(size : string = "L",message: string ="I love TypeScript" ) : void {
    console.log(`Make a shirt of size ${size} with content ${message}! Noted`);
    
}
make_shirt();
make_shirt("M");
make_shirt("L","<CODE BLOODED/>")