function make_album(artist:string,name:string,limit:any=null):object{
    let r : object =  {name:name, artist:artist};
    if(limit==null){
        return r 
    }else{
        return {...r,limit:limit}
    }
}

console.log(make_album("nusrat fateh","Fav songs"));
console.log(make_album("Arjit singh","Sad songs"));
console.log(make_album("tony kakkar","Aalto faltoo",5));