let magician_names :string[] = ["albert einstein","bill gates","brendan eich"]
function show_magicians(x:string[]):void{
    for (const y of x) {
        console.log(y);
        
    }
}
show_magicians(magician_names)