let magician_names :string[] = ["albert einstein","bill gates","brendan eich"]
function show_magicians(x:string[]):void{
    for (const y of x) {
        console.log(y);
        
    }
}

function make_great(x:string[]):void{
    for (let i = 0; i < x.length; i++) {
        x[i] ="Great " + x[i];
        
    }
}
make_great(magician_names)
show_magicians(magician_names)