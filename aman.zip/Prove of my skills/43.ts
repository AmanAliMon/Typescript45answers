let magician_names :string[] = ["albert einstein","bill gates","brendan eich"]
function show_magicians(x:string[]):void{
    for (const y of x) {
        console.log(y);
        
    }
}

function make_great(x:string[]):string[]{
    let y:string[] = []
    for (let i = 0; i < x.length; i++) {
        y[i] ="Great " + x[i];
        
    }
    return y
}
let great_magicians : string[]  = make_great(magician_names)
show_magicians(magician_names)
show_magicians(great_magicians)