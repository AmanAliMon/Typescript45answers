function order_sandwhich(...args):void{
let r= [...args]
console.log(`Make a sandwhich with ${r}`);
}
order_sandwhich("mayonise","ham")
order_sandwhich("beef","carrots")
order_sandwhich("mayonise","ketchup")