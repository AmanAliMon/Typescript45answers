function new_car(manufacturer:string,modal:number,...args:any):object{
    return {manufacturer:manufacturer,modal:modal,...args}
}
console.log(new_car("Honda civic",456789));
console.log(new_car("Honda civic",456789,"red"));
