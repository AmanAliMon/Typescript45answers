var famous_person: string = "Jaun Elia";
var message: string = "\"Yeh Mujh ko chain kyun nhi prta?  Woh aik hi shaks tha jahan main kia!\"";
console.log(famous_person+": "+message)