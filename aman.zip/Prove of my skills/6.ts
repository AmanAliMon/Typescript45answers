let someone:string = "\n\tAman  \t"
console.log(someone);
console.log(someone.trim());
// removing the white spaces