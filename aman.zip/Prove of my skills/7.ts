console.log(4*2);
console.log(4+4);
console.log(10-2);
console.log(16/2);
console.log(4*3+1-10/2);