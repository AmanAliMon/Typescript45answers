console.log(5+3);
console.log(6+2);
console.log(1+7);
console.log(4+4);
