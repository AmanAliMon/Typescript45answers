let num : number = 7;
let message: string = "And, the number is: "+String(num);
console.log(message);
